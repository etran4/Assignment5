package A4;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.AfterEach;
import static org.junit.Assert.assertEquals;
import static org.junit.jupiter.api.Assertions.*;

class HolidayBonusTestSTUDENT 
{
	private double[][] dataSetSTUDENT = {{1,2,3},{4,2,3},{9,5,7},{3,7}};  
	
	@BeforeEach
	void setUp() throws Exception 
	{
	}

	@AfterEach
	void tearDown() throws Exception 
	{
	}

	@Test
	void testCalculateHolidayBonus() 
	{
		double[] result = HolidayBonus.calculateHolidayBonus(dataSetSTUDENT, 5000,1000,2000);
		assertEquals(3000.0,result[0],.001);
		assertEquals(6000.0,result[1],.001);
		assertEquals(12000.0,result[2],.001);
		//assertEquals(5000.0,result[3],.001);
	}

	@Test
	void testCalculateTotalHolidayBonus() 
	{
		assertEquals(28000.0, HolidayBonus.calculateTotalHolidayBonus(dataSetSTUDENT, 5000,1000,2000),.001);
	}

}
//Ethan Tran