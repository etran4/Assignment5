package A4;

import java.util.Scanner;
import java.lang.String;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

public class TwoDimRaggedArrayUtility 
{
	public static double getAverage(double[][] data)
	{
		double total = 0;
		int numOfElements = 0;
		
		for (int x = 0; x < data.length; x++)
		{
			for (int y = 0; y < data[x].length; y++)
			{
				total += data[x][y];
				numOfElements++;
			}
		}
		return total/numOfElements;
	}
	
	public static double getColumnTotal(double[][] data, int col)
	{
		double total = 0;
		
		for (int x = 0; x < data.length; x++)
		{
			if (data[x].length <= col)
			{
				continue;
			}
			total += data[x][col];
		}
		return total;
	}
	
	static double getHighestInArray(double[][] data)
	{
		double max = data[0][0];
		
		for (int x = 0; x < data.length; x++)
		{
			for (int y = 0; y < data[x].length; y++)
			{
				if (data[x][y] > max)
				{
					max = data[x][y];
				}
			}
		}
		return max;
	}
	
	public static double getHighestInColumn(double[][] data, int col)
	{
		int tempIndex = 0;
		
		while (data[tempIndex].length <= col)
		{
			tempIndex++;
		}
		double max = data[tempIndex][col];
		
		for (int x = 0; x < data.length; x++)
		{
			if (data[x].length <= col)
			{
				continue;
			}
			if (data[x][col] > max)
			{
				max = data[x][col];
			}
		}
		return max;
	}
	
	public static int getHighestInColumnIndex(double[][] data, int col)
	{
		int tempIndex = 0;
		
		while (data[tempIndex].length <= col)
		{
			tempIndex++;
		}
		double max = data[tempIndex][col];
		int rowIndex = tempIndex;
		
		for (int x = 0; x < data.length; x++)
		{
			if (data[x].length <= col)
			{
				continue;
			}
			if (data[x][col] > max)
			{
				max = data[x][col];
				rowIndex = x;
			}
		}
		return rowIndex;
	}
	
	public static double getHighestInRow(double[][] data, int row)
	{
		double max = data[row][0];
		
		for (int x = 0; x < data[row].length; x++)
		{
			if (data[row][x] > max)
			{
				max = data[row][x];
			}
		}
		return max;
	}
	
	public static int getHighestInRowIndex(double[][] data, int row)
	{
		double max = data[row][0];
		int colIndex = 0;
		
		for (int x = 0; x < data[row].length; x++)
		{
			if (data[row][x] > max)
			{
				max = data[row][x];
				colIndex = x;
			}
		}
		return colIndex;
	}
	
	public static double getLowestInArray(double[][] data)
	{
		double min = data[0][0];
		
		for (int x = 0; x < data.length; x++)
		{
			for (int y = 0; y < data[x].length; y++)
			{
				if (data[x][y] < min)
				{
					min = data[x][y];
				}
			}
		}
		return min;
	}
	
	public static double getLowestInColumn(double[][] data, int col)
	{
		int tempIndex = 0;
		
		while (data[tempIndex].length <= col)
		{
			tempIndex++;
		}
		double min = data[tempIndex][col];
		
		for (int x = 0; x < data.length; x++)
		{
			if (data[x].length <= col)
			{
				continue;
			}
			if (data[x][col] < min)
			{
				min = data[x][col];
			}
		}
		return min;
	}
	
	public static int getLowestInColumnIndex(double[][] data, int col)
	{
		int tempIndex = 0;
		
		while (data[tempIndex].length <= col)
		{
			tempIndex++;
		}
		double min = data[tempIndex][col];
		int rowIndex = tempIndex;
		
		for (int x = 0; x < data.length; x++)
		{
			if (data[x].length <= col)
			{
				continue;
			}
			if (data[x][col] < min)
			{
				min = data[x][col];
				rowIndex = x;
			}
		}
		return rowIndex;
	}
	
	public static double getLowestInRow(double[][] data, int row)
	{
		double min = data[row][0];
		
		for (int x = 0; x < data[row].length; x++)
		{
			if (data[row][x] < min)
			{
				min = data[row][x];
			}
		}
		return min;
	}
	
	public static int getLowestInRowIndex(double[][] data, int row)
	{
		double min = data[row][0];
		int colIndex = 0;
		
		for (int x = 0; x < data[row].length; x++)
		{
			if (data[row][x] < min)
			{
				min = data[row][x];
				colIndex = x;
			}
		}
		return colIndex;
	}
	
	public static double getRowTotal(double[][] data, int row)
	{
		double total = 0;
		
		for (int x = 0; x < data[row].length; x++)
		{
			total += data[row][x];
		}
		return total;
	}
	
	public static double getTotal(double[][] data)
	{
		double total = 0;
		
		for (int x = 0; x < data.length; x++)
		{
			for (int y = 0; y < data[x].length; y++)
			{
				total += data[x][y];
			}
		}
		return total;
	}

	public static double[][] readFile(File file) throws FileNotFoundException
	{
		Scanner scan = new Scanner(file);
		int x = 0;
		
		while (scan.hasNextLine())
		{
			scan.nextLine();
			x++;
		}	
		scan.close();
		scan = new Scanner(file);
		
	    double[][] data = new double[x][];
	   
	    for (int row = 0; row < x; row++)
	    {
	    	String[] rowElements = scan.nextLine().split(" ");
	    	data[row] = new double[rowElements.length];
	    	
	    	for (int y = 0; y < rowElements.length; y++) 
	    	{
	 	       data[row][y]= Double.parseDouble(rowElements[y]);   
	 	     }   	
	    }
	    scan.close();
		return data;
	}
	
	public static void writeToFile(double[][] data, File outputFile) throws FileNotFoundException
	{
		PrintWriter writer = new PrintWriter(outputFile);
		
		for (int x = 0; x < data.length; x++)
		{
			for (int y = 0; y < data[x].length; y++)
			{
				writer.print(data[x][y] + " ");
			}
			writer.print("\n");
		}
		writer.close();
	}
}
// Ethan Tran
