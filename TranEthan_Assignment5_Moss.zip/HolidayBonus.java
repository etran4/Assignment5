package A4;

public class HolidayBonus 
{
	public static double[] calculateHolidayBonus(double[][] data, double high, double low, double other)
	{
		double[] holidayBonuses = new double[data.length];
		double bonusTotal = 0;
		double changingEle;
		
		for (int x = 0; x < data.length; x++)
		{
			bonusTotal = 0;
			
			for (int y = 0; y < data[x].length; y++)
			{
				changingEle = data[x][y];
			
				if (changingEle < 0)
				{
					continue;
				}
			
				if (TwoDimRaggedArrayUtility.getHighestInColumnIndex(data, y) == x)
				{
					bonusTotal += high;
				}
				else if (TwoDimRaggedArrayUtility.getLowestInColumnIndex(data, y) == x)
				{
					bonusTotal += low;
				}
				else
				{
					bonusTotal += other;
				}
			}
			holidayBonuses[x] = bonusTotal;
		}
		return holidayBonuses;
	}
	
	public static double calculateTotalHolidayBonus(double[][] data, double high, double low, double other)
	{
		double bonusTotal = 0;
		double changingEle;
		
		for (int x = 0; x < data.length; x++)
		{
			for (int y = 0; y < data[x].length; y++)
			{
				changingEle = data[x][y];
			
				if (changingEle < 0)
				{
					continue;
				}
				
				if (TwoDimRaggedArrayUtility.getHighestInColumnIndex(data, y) == x)
				{
					bonusTotal += high;
				}
				else if (TwoDimRaggedArrayUtility.getLowestInColumnIndex(data, y) == x)
				{
					bonusTotal += low;
				}
				else
				{
					bonusTotal += other;
				}
			}
		}
		return bonusTotal;
	}
}

//Ethan Tran